#Welcome to PathFinding.js documentation

Table of Contents

* User Guide
    * [Introduction](./user-guide/introduction.md)
    * [Installation](./user-guide/installation.md)
	* [Getting Started](./user-guide/getting-started.md)
	* [Obstacles](./user-guide/obstacles.md)
	* [Diagonal Movement](./user-guide/diagonal-movement.md)
	* [FAQ](./user-guide/faq.md)
* Contributor Guide
    * [Contributing](./contributor-guide/contributing.md)
	* [Developing](./contributor-guide/developing.md)
	* [Authors](./contributor-guide/authors.md)