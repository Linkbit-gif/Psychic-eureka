# appCreation
Legend of AIémon
Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\ad2=Serial No
Stardock Aquarium Desktop 2006 |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\adu=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\adu=Serial No
Stardock Aquarium Desktop 2007 |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\ad3=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\ad3=Serial No
Stardock Blog Navigator Pro |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\bn=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\bn=Serial No
Stardock CursorXP Plus |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\cxp=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\cxp=Serial No
Stardock Desktop Pet |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\pt1=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\pt1=Serial No
Stardock DesktopX |Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\DesktopX=Name|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\DesktopX=Serial
Stardock Natural Desktop |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\nd=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\nd=Serial No
Stardock ObjectDesktop |First Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ObjectDesktop=First Name|Last Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ObjectDesktop=Last Name|Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ObjectDesktop=Email|Expires=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ObjectDesktop=Expires|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ObjectDesktop=Serial No
Stardock Orion Icon Suite |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\or=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\or=Serial No
Stardock ThinkDesk |First Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ThinkDesk=First Name|Last Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ThinkDesk=Last Name|Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ThinkDesk=Email|Expires=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ThinkDesk=Expires|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\ThinkDesk=Serial No
Stardock Unorthodox Suite |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\un=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\un=Serial No
Stardock Utopia Icon Suite [CD] |Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\ut=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\ut=Serial No
Stardock WinCustomize |First Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\WinCustomize=First Name|Last Name=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\WinCustomize=Last name|Email=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\WinCustomize=Email|Expires=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\WinCustomize=Expires|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\WinCustomize=Serial No
Stardock|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Stardock\ComponentManager\Stardock\odp=Serial No
Submarine TITANS|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Ellipse Studios\Submarine Titans\Version=Item
SuperCleaner|Name=HKEY_CURRENT_USER\Software\SuperCleaner\Registration=Name|Key=HKEY_CURRENT_USER\Software\SuperCleaner\Registration=Code
Swiftdog GameHike|Name=HKEY_LOCAL_MACHINE\SOFTWARE\SWIFTDOG\GameHike=Name|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\SWIFTDOG\GameHike=Serial
Swiftdog GameThrust|Name=HKEY_LOCAL_MACHINE\SOFTWARE\SWIFTDOG\GameThrust=Name|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\SWIFTDOG\GameThrust=Serial
Symantec ACT! 6|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Symantec\ACT!\install=SerialNumber
Symantec Norton Internet Security 2007|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Symantec\CCPD-LC\KStore\00000082\00000049\000000b9=Key
Symantec Norton Partionmagic 8.05|Name=HKEY_LOCAL_MACHINE\SOFTWARE\Symantec\Norton PartitionMagic\8.0\UserInfo=Name|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Symantec\Norton PartitionMagic\8.0\UserInfo=SerialNumber|Company=HKEY_LOCAL_MACHINE\SOFTWARE\Symantec\Norton PartitionMagic\8.0\UserInfo=Company
Symantec Norton SystemWorks 2008 11.0.1|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Symantec\CCPD-LC\KStore\00000082\000000d2\0000025f=Key
Tag&Rename|Name=HKEY_CURRENT_USER\Software\Softpointer\Tag&Rename\Config=Name|Key=HKEY_CURRENT_USER\Software\Softpointer\Tag&Rename\Config=cbVQFFtoTagReplaseUnde
Techsmith Camtasia Studio 3.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\3.0=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\3.0=RegistrationKey
Techsmith Camtasia Studio 4.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\4.0=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\4.0=RegistrationKey
Techsmith Camtasia Studio 5.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\5.0=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\5.0=RegistrationKey
Techsmith Camtasia Studio 6.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\6.0=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\6.0=RegistrationKey
Techsmith Camtasia Studio 6.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\6.0=RegisteredTo|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\Camtasia Studio\6.0=RegistrationKey
Techsmith SnagIt 7.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\SnagIt\7=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\SnagIt\7=RegistrationKey
Techsmith SnagIt 8.0|Name=HKEY_CURRENT_USER\Software\TechSmith\SnagIt\8=RegisteredTo|Key=HKEY_CURRENT_USER\Software\TechSmith\SnagIt\8=RegistrationKey
Techsmith SnagIt 8.1|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\SnagIt\8=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\SnagIt\8=RegistrationKey
Techsmith SnagIt 9.0|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\SnagIt\9=RegisteredTo|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TechSmith\SnagIt\9=RegistrationKey
Teleport Pro|Name=HKEY_LOCAL_MACHINE\SOFTWARE\Tennyson Maxwell\Teleport Pro=Name|Company=HKEY_LOCAL_MACHINE\SOFTWARE\Tennyson Maxwell\Teleport Pro=Company
TGTSoft StyleXP|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TGT Soft\StyleXP=RegKey
The Bat!|Version=HKEY_CURRENT_USER\Software\RIT\The Bat!=Version|Registration code=HKEY_CURRENT_USER\Software\RIT\The Bat!=RegistrationBlock
The Gladiators|Key=HKEY_CURRENT_USER\Software\Eugen Systems\The Gladiators=RegNumber
The Gladiators|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Eugen Systems\The Gladiators=RegNumber
The Sims 2 Apartment Life|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Apartment Life\ergc=
The Sims 2 Bon Voyage|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Bon Voyage\ergc=
The Sims 2 Celebration Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Celebration Stuff\ergc=
The Sims 2 Deluxe|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Deluxe\ergc=
The Sims 2 Double Deluxe|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Double Deluxe\ergc=
The Sims 2 Family Fun Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Family Fun Stuff\ergc=
The Sims 2 Free Time|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 FreeTime\ergc=
The Sims 2 Glamour Life Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Glamour Life Stuff\ergc=
The Sims 2 H M Fashion Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 H M Fashion Stuff\ergc=
The Sims 2 IKEA Home Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 IKEA Home Stuff\ergc=
The Sims 2 Kitchen & Bath Interior Design Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Kitchen & Bath Interior Design Stuff\ergc=
The Sims 2 Nightlife|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Nightlife\ergc=
The Sims 2 Open for Business|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Open for Business\ergc=
The Sims 2 Pets|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Pets\ergc=
The Sims 2 Seasons|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Seasons\ergc=
The Sims 2 Teen Style Stuff|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 Teen Style Stuff\ergc=
The Sims 2 University|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2 University\ergc=
The Sims 2|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\EA Games\The Sims 2\ergc=
The Sims Castaway Stories|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\The Sims Castaway Stories\ergc=
The Sims Deluxe|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Deluxe\ergc=
The Sims Hot Date|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Hot Date\ergc=
The Sims House Party|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims House Party\ergc=
The Sims Life Stories|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\The Sims Life Stories\ergc=
The Sims Livin’ Large|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Livin' Large\ergc=
The Sims Makin’ Magic|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Makin' Magic\ergc=
The Sims Pet Stories|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\The Sims Pet Stories\ergc=
The Sims Superstar|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Superstar\ergc=
The Sims Unleashed|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Unleashed\ergc=
The Sims Vacation|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims Vacation\ergc=
The Sims|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Electronic Arts\Maxis\The Sims\ergc=
TMPGEnc Plus 2.5|Name=HKEY_LOCAL_MACHINE\SOFTWARE\Pegasys Inc.\TMPGEnc Plus\2.5=UserName|Company=HKEY_LOCAL_MACHINE\SOFTWARE\Pegasys Inc.\TMPGEnc Plus\2.5=CompanyName|Serial=HKEY_CURRENT_USER\SOFTWARE\Pegasys Inc.\TMPGEnc Plus\2.5=SerialID
Tobit ClipIncPlayer 4|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Tobit\Tobit ClipInc\Server\Setup=LicenseNo
TrackMania United|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Nadeo\TmUnited\Keys\License0=Key
Trend Micro PC-cillin Antivirus 11|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TrendMicro\PC-cillin=register no.
Trend Micro PC-cillin Antivirus 2007|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\TrendMicro\AntiVirus\15=SerialNo
TuneUP Utilities 2006|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\5.0=UserName|Company=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\5.0=Company|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\5.0=RegCode
TuneUP Utilities 2007|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\6.0=UserName|Company=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\6.0=Company|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\6.0=RegCode
TuneUp Utilities 2009|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\8.0=UserName|Company=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\8.0=Company|Key=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\8.0=ProductKey
TuneUp Utilities 2010|Company=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\9.0=Company|Name=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\9.0=UserName|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\TuneUp\Utilities\9.0=ProductKey
Unreal Tournament 2003|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Unreal Technology\Installed Apps\UT2003=CDKey
Unreal Tournament 2004|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Unreal Technology\Installed Apps\UT2004=CDKey
VanDyke SecureFX|Version=HKEY_LOCAL_MACHINE\SOFTWARE\VanDyke\SecureFX\License=Version|Key=HKEY_LOCAL_MACHINE\SOFTWARE\VanDyke\SecureFX\License=key|Issue Date=HKEY_LOCAL_MACHINE\SOFTWARE\VanDyke\SecureFX\License=Issue Date|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\VanDyke\SecureFX\License=Serial Number
VMware Server|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\VMware, Inc.\VMware Server\License.vs.1.0-00=Serial
VMware Workstation 4.0|Version=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation=ProductVersion|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation\License.ws.4.0=Serial
VMware Workstation 5.0|Version=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation=ProductVersion|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation\License.ws.5.0=Serial
VMware Workstation 6.*|Version=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation=ProductVersion|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation\License.ws.6.0.200610=Serial
VMware Workstation 6.*|Version=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation=ProductVersion|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation\License.ws.6.0.200907=Serial
VMware Workstation ACE Edition 6.0|Version=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation\License.wsace.6.0.200907=LicenseVersion|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Vmware, Inc.\Vmware Workstation\License.wsace.6.0.200907=Serial
VSO BlindWrite 6|Key=HKEY_CURRENT_USER\Software\VSO\BW6=LicenseKey
VSO ConvertXtoDVD|Key=HKEY_LOCAL_MACHINE\SOFTWARE\VSO\ConvertXtoDVD\=LicenseKey
VSO ConvertXtoDVD|Version=HKEY_CURRENT_USER\Software\VSO\ConvertXToDVD\NetUpdate=NetUpdate_LastVersion|Key (Machine)=HKEY_LOCAL_MACHINE\SOFTWARE\VSO\ConvertXtoDVD=LicenseKey|Key (User)=HKEY_CURRENT_USER\Software\VSO\ConvertXToDVD=LicenseKey
VSO ConvertXtoDVD|Version=HKEY_CURRENT_USER\Software\VSO\ConvertXToDVD\NetUpdate=NetUpdate_LastVersion|Key=HKEY_CURRENT_USER\Software\VSO\ConvertXToDVD=LicenseKey
Winamp 5|Name=HKEY_LOCAL_MACHINE\SOFTWARE\Nullsoft\Winamp=regname|Key=HKEY_LOCAL_MACHINE\SOFTWARE\Nullsoft\Winamp=regkey
WinImage|Name=HKEY_CURRENT_USER\Software\WinImage=NameRegistered|Key=HKEY_CURRENT_USER\Software\WinImage=CodeRegistered
WinPatrol|Key=HKEY_LOCAL_MACHINE\SOFTWARE\BillP Studios\WinPatrol=RegNumber
Winzip|Name (Machine)=HKEY_LOCAL_MACHINE\SOFTWARE\Nico Mak Computing\WinZip\Winini=Name1|Name (User)=HKEY_CURRENT_USER\Software\Nico Mak Computing\WinZip\Winini=Name1|Key (Machine)=HKEY_LOCAL_MACHINE\SOFTWARE\Nico Mak Computing\WinZip\Winini=SN1|Key (User)=HKEY_CURRENT_USER\Software\Nico Mak Computing\WinZip\Winini=SN1
WS FTP|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Ipswitch\WS_FTP=SerialNumber
X1 Desktop Search|Installed Build=HKEY_LOCAL_MACHINE\SOFTWARE\X1 Desktop Search=CurrentInstallVersion|Registration=HKEY_LOCAL_MACHINE\SOFTWARE\X1 Desktop Search=Registration
XThink Calculator|Name=HKEY_LOCAL_MACHINE\SOFTWARE\xThink\Calculator\UserInfo=UserName|Email=HKEY_LOCAL_MACHINE\SOFTWARE\xThink\Calculator\UserInfo=Email|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\xThink\Calculator\UserInfo=KeyCode
ZoneAlarm|Name=HKEY_LOCAL_MACHINE\SOFTWARE\Zone Labs\ZoneAlarm\Registration\=RegisteredOwner|Company=HKEY_LOCAL_MACHINE\SOFTWARE\Zone Labs\ZoneAlarm\Registration\=RegisteredOrganization|Serial=HKEY_LOCAL_MACHINE\SOFTWARE\Zone Labs\ZoneAlarm\Registration\=SerialNum
